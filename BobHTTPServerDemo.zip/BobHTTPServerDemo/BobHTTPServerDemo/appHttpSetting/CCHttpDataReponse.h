//
//  CCHttpDataReponse.h
//  catClaw
//
//  Created by iOS Developer 1 on 16/3/11.
//  Copyright © 2016年 Joey. All rights reserved.
//

#import "HTTPDataResponse.h"

@interface CCHttpDataReponse : HTTPDataResponse

@end
